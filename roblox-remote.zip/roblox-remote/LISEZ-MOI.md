# Dossier pour Remote Control

1. Dézippez ce dossier dans un endroit simple, par exemple `C:\Users\<vous>\Documents\roblox-remote`.
   Évitez un dossier caché (nom qui commence par un point) ou un dossier système.
2. Dans l'app Claude Desktop : Paramètres > Claude Code > Remote Control > ajouter ce dossier.
3. Quand il apparaît « en ligne », dites « réessaie » à la session de gestion.

Contenu : textes de publication (PUBLICATION_A_COLLER.md), vignettes (vignettes/), mémoire du studio (obsidian-studio/), scripts Blender (scripts/).
